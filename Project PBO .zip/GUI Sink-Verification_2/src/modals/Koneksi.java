/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modals;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


/**
 *
 * @author User
 */
public class Koneksi {
    private static Connection MySQLlConfig;
    public static Connection configDB() throws SQLException{
        try {
            String url = "jdbc:mysql://localhost:3306/dbsinkverification";
            String user = "root";
            String pass = "";
            
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            MySQLlConfig = DriverManager.getConnection(url, user, pass);
            
        } catch (Exception e) {
            System.out.println("KONEKSI KE DATABASE GAGAL " + e.getMessage());
        }
        return MySQLlConfig;
    }
    
}
