/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.V_homeRT;
import view.V_dataTerverifikasiRT;
/**
 *
 * @author User
 */
public class c_dataTerverifikasiRT {
    V_dataTerverifikasiRT view;
    
    public c_dataTerverifikasiRT(V_dataTerverifikasiRT view){
        this.view = view;
        this.view.setVisible(true);
        this.view.klikKembali(new tbKembali());
}

    private class tbKembali implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_homeRT homeRT = new controller.c_homeRT(new V_homeRT());
            view.setVisible(false);
        }
    }
}