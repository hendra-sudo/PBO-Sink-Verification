/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.V_homeVVK;
import view.V_konfirmasiVVK;
/**
 *
 * @author User
 */
public class c_konfirmasiVVK {
    V_konfirmasiVVK view;
    
    public c_konfirmasiVVK(V_konfirmasiVVK view){
        this.view = view;
        this.view.setVisible(true);
        this.view.klikKembali(new tbKembali());
}

    private class tbKembali implements ActionListener {


        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_homeVVK homeVVK = new controller.c_homeVVK(new V_homeVVK());
            view.setVisible(false);
        }
    }
}
