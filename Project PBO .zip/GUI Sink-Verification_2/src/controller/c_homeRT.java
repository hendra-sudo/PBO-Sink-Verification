/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
//import view.V_ajukanPenerimaKD;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.V_hasilSurveyRT;
import view.V_ajukanPenerimaBantuanRT;
import view.V_dataTerverifikasiRT;
import view.V_homeRT;
import view.V_login;
/**
 *
 * @author User
 */
public class c_homeRT {
    V_homeRT view;
    
    public c_homeRT(V_homeRT view){
        this.view = view;
        this.view.setVisible(true);
        this.view.klikLogout(new tbLogout());
        this.view.klikHasilSurveyRT(new tbHasilSurveyRT());
        this.view.klikAjukanPenerimaBantuanRT(new tbAjukanPenerimaBantuanRT());
        this.view.klikDataTerverifikasiRT(new tbDataTerverifikasiRT());
        this.view.kliknull(new tbnull());
    }

    private static class tbnull implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }

    private class tbLogout implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
             controller.c_login login = new controller.c_login(new V_login());
            view.setVisible(false);
        }
    }

    private class tbHasilSurveyRT implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_hasilSurveyRT hasilSurveyRT  = new controller.c_hasilSurveyRT (new V_hasilSurveyRT ());
            view.setVisible(false);
        }
    }

    private class tbAjukanPenerimaBantuanRT implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_ajukanPenerimaBantuanRT ajukanPenerimaBantuanRT = new controller.c_ajukanPenerimaBantuanRT(new V_ajukanPenerimaBantuanRT());
            view.setVisible(false);
        }
    }

    private class tbDataTerverifikasiRT implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_dataTerverifikasiRT dataTerverifikasiRT = new controller.c_dataTerverifikasiRT(new V_dataTerverifikasiRT());
            view.setVisible(false);
        }
    }
}
