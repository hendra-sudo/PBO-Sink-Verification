/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.V_dasboard;
import view.V_home;
import view.V_homeKD;
import view.V_homeRT;
import view.V_homeVVK;

/**
 *
 * @author User
 */
public class c_dasboard {
    V_dasboard view;
    
    public c_dasboard(V_dasboard view){
        this.view = view;
        this.view.setVisible(true);
        this.view.klikHomeAdmin(new tbHomeAdmin());
        this.view.klikHomeKepalaDesa(new tbHomeKepalaDesa());
        this.view.klikHomeKetuaRT(new tbHomeKetuaRT());
        this.view.klikHomeVerifikator(new tbHomeVerifikator());
        
    }

    private class tbHomeAdmin implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_home home = new controller.c_home(new V_home());
            view.setVisible(false);
        }
    }

    private class tbHomeVerifikator implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_homeVVK homeVVK = new controller.c_homeVVK(new V_homeVVK());
            view.setVisible(false);
        }
    }

    private class tbHomeKetuaRT implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_homeRT homeRT = new controller.c_homeRT(new V_homeRT());
            view.setVisible(false);
        }
    }

    private class tbHomeKepalaDesa implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_homeKD homeKD = new controller.c_homeKD(new V_homeKD());
            view.setVisible(false);
        }
    }

    
}
