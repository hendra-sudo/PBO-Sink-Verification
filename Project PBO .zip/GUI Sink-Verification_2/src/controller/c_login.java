/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.V_login;
import view.V_home;
import view.V_dasboard;
/**
 *
 * @author User
 */
public class c_login {
    V_login view;
    
    public c_login(V_login view){
        this.view = view;
        this.view.setVisible(true);
        this.view.klikLogin(new tbLogin());
    }

    private class tbLogin implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
           controller.c_dasboard dasboard = new controller.c_dasboard(new V_dasboard());
           view.setVisible(false);
        }
    }
}
