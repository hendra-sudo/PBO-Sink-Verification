/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.V_ajukanPenerimaKD;
import view.V_daftarkanAkunKD;
import view.V_dataTerverifikasiKD;
import view.V_hasilSurveyKD;
import view.V_homeKD;
import view.V_login;

/**
 *
 * @author User
 */
public class c_homeKD {
    V_homeKD view;
    
    public c_homeKD(V_homeKD view){
        this.view = view;
        this.view.setVisible(true);
        this.view.klikLogout(new tbLogout());
        this.view.klikDaftarkanAkunKD(new tbDaftarkanAkunKD());
        this.view.klikHasilSurveyKD(new tbHasilSurvey());
        this.view.klikAjukanPenerimaKD(new tbAjukanPenerima());
        this.view.klikDataTerverifikasiKD(new tbDataTerverifikasi());
    }

    private class tbLogout implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_login login = new controller.c_login(new V_login());
            view.setVisible(false);
        }
    }

    private class tbDataTerverifikasi implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_dataTerverifikasiKD DataTerverifikasiKD = new controller.c_dataTerverifikasiKD(new V_dataTerverifikasiKD());
            view.setVisible(false);
        }
    }

    private class tbAjukanPenerima implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_ajukanPenerimaKD AjukanPenerimaKD = new controller.c_ajukanPenerimaKD(new V_ajukanPenerimaKD());
            view.setVisible(false);
        }
    }

    private class tbHasilSurvey implements ActionListener {


        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_hasilSurveyKD HasilSurveyKD = new controller.c_hasilSurveyKD(new V_hasilSurveyKD());
            view.setVisible(false);
        }
    }

    private class tbDaftarkanAkunKD implements ActionListener {


        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_daftarkanAkunKD daftarkanAkunKD = new controller.c_daftarkanAkunKD(new V_daftarkanAkunKD());
            view.setVisible(false);
        }
    }
}
