/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.V_dataSurvey;
import view.V_login;
import view.V_home;
import view.V_daftarkanAkun;
import view.V_jadwalSurvey;
import view.V_daftarAkun;
/**
 *
 * @author User
 */
public class c_home {
    V_home view;
    
    public c_home(V_home view){
        this.view = view;
        this.view.setVisible(true);
        this.view.klikLogout(new tbLogout());
        this.view.klikProfil(new tbProfil());
        this.view.klikDataSurvey(new tbDataSurvey());
        this.view.klikJadwalSurvey(new tbJadwalSurvey());
        this.view.klikFoto(new tbFoto());
    }

   

    private class tbFoto implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_foto foto = new controller.c_foto(new V_daftarAkun());
            view.setVisible(false);
        }
    }

    private class tbJadwalSurvey implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_jadwalSurvey jadwalSurvey = new controller.c_jadwalSurvey(new V_jadwalSurvey());
            view.setVisible(false);
        }
    }

    private class tbDataSurvey implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_dataSurvey dataSurvey = new controller.c_dataSurvey(new V_dataSurvey());
            view.setVisible(false);
        }
    }

    private class tbProfil implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_profil profil = new controller.c_profil(new V_daftarkanAkun());
            view.setVisible(false);
        }
    }

    private class tbLogout implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_login login = new controller.c_login(new V_login());
            view.setVisible(false);
        }
    }
}
