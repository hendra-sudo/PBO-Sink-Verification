/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.V_jadwalSurveyVVK;
import view.V_isiFormVVK;
import view.V_dataTerverifikasiVVK;
import view.V_konfirmasiVVK;
import view.V_homeVVK;
import view.V_login;

/**
 *
 * @author User
 */
public class c_homeVVK {
    V_homeVVK view;
    
    public c_homeVVK(V_homeVVK view){
        this.view = view;
        this.view.setVisible(true);
        this.view.klikLogout(new tbLogout());
        this.view.klikJadwalSurveyVVK(new tbJadwalSurveyVVK());
        this.view.klikDataTerverifikasiVVK(new tbDataTerverifikasiVVK());
        this.view.klikIsiFormVVK(new tbIsiFormVVK());
        this.view.klikKonfirmasiVVK(new tbKonfirmasiVVK());
}

    private class tbLogout implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_login login = new controller.c_login(new V_login());
            view.setVisible(false);
        }
    }

    private  class tbKonfirmasiVVK implements ActionListener {


        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_konfirmasiVVK konfirmasiVVK = new controller.c_konfirmasiVVK(new V_konfirmasiVVK());
            view.setVisible(false);
        }
    }

    private class tbIsiFormVVK implements ActionListener {

  

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_isiFormVVK isiFormVVK = new controller.c_isiFormVVK(new V_isiFormVVK());
            view.setVisible(false);
        }
    }

    private class tbDataTerverifikasiVVK implements ActionListener {



        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_dataTerverifikasiVVK dataTerverifikasiVVK = new controller.c_dataTerverifikasiVVK(new V_dataTerverifikasiVVK());
            view.setVisible(false);
        }
    }

    private class tbJadwalSurveyVVK implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_jadwalSurveyVVK jadwalSurveyVVK = new controller.c_jadwalSurveyVVK(new V_jadwalSurveyVVK());
            view.setVisible(false);
        }
    }
    }
