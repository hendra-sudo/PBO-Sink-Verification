/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.V_hasilSurveyKD;
import view.V_homeKD;
/**
 *
 * @author User
 */
public class c_hasilSurveyKD {
    V_hasilSurveyKD view;
    
    public c_hasilSurveyKD(V_hasilSurveyKD view){
        this.view = view;
        this.view.setVisible(true);
        this.view.klikKembali(new tbKembali());
    }

    private class tbKembali implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.c_homeKD homeKD = new controller.c_homeKD(new V_homeKD());
            view.setVisible(false);
        }
    }
}
